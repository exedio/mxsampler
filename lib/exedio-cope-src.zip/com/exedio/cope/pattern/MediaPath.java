/*
 * Copyright (C) 2004-2012  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope.pattern;

import static com.exedio.cope.util.CharsetName.UTF8;
import static javax.servlet.http.HttpServletResponse.SC_MOVED_PERMANENTLY;
import static javax.servlet.http.HttpServletResponse.SC_NOT_FOUND;
import static javax.servlet.http.HttpServletResponse.SC_NOT_MODIFIED;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.exedio.cope.Condition;
import com.exedio.cope.ConnectProperties;
import com.exedio.cope.Item;
import com.exedio.cope.Join;
import com.exedio.cope.Model;
import com.exedio.cope.NoSuchIDException;
import com.exedio.cope.Pattern;
import com.exedio.cope.instrument.BooleanGetter;
import com.exedio.cope.instrument.Wrap;
import com.exedio.cope.util.Hex;
import com.exedio.cope.util.MessageDigestUtil;

public abstract class MediaPath extends Pattern
{
	private static final long serialVersionUID = 1l;

	private Mount mountIfMounted;

	private static final class Mount
	{
		final String urlPath;
		final boolean preventUrlGuessing;

		Mount(final MediaPath feature)
		{
			this.urlPath = feature.getType().getID() + '/' + feature.getName() + '/';
			this.preventUrlGuessing = feature.isAnnotationPresent(PreventUrlGuessing.class);
			if(preventUrlGuessing && feature.isAnnotationPresent(RedirectFrom.class))
				throw new RuntimeException(
						"not yet implemented: @" + PreventUrlGuessing.class.getSimpleName() +
						" at " + feature.getID() +
						" together with @" + RedirectFrom.class.getSimpleName());
		}
	}

	private String mediaRootUrl = null;

	@Override
	protected void onMount()
	{
		super.onMount();
		this.mountIfMounted = new Mount(this);
	}

	private Mount mount()
	{
		final Mount result = this.mountIfMounted;
		if(result==null)
			throw new IllegalStateException("feature not mounted");
		return result;
	}

	final String getUrlPath()
	{
		return mount().urlPath;
	}

	public final boolean isUrlGuessingPrevented()
	{
		return mount().preventUrlGuessing;
	}

	private final String getMediaRootUrl()
	{
		if(mediaRootUrl==null)
			mediaRootUrl = getType().getModel().getConnectProperties().getMediaRootUrl();

		return mediaRootUrl;
	}

	public boolean isContentTypeWrapped()
	{
		return true;
	}

	/**
	 * Represents a resource to be delivered the media servlet.
	 * Provides methods for retrieving different types of urls.
	 * All methods of Locator do not require a connected model or a transaction to work.
	 */
	public final class Locator
	{
		private final Item item;
		private final String catchphrase;
		private final String extension;
		private final String secret;

		Locator(
				final Item item,
				final String catchphrase,
				final String extension,
				final String secret)
		{
			this.item = item;
			this.catchphrase = catchphrase;
			this.extension = extension;
			this.secret = secret;
		}

		public MediaPath getFeature()
		{
			return MediaPath.this;
		}

		public String getPath()
		{
			final StringBuilder bf = new StringBuilder();
			appendPath(bf);
			return bf.toString();
		}

		/**
		 * Is equivalent to <tt>bf.{@link StringBuilder#append(String) append}({@link #getPath()});</tt>
		 */
		public void appendPath(final StringBuilder bf)
		{
			bf.append(getUrlPath());
			item.appendCopeID(bf);

			if(catchphrase!=null)
				bf.append('/').append(catchphrase);

			if(extension!=null)
				bf.append(extension);

			if(secret!=null)
				bf.append("?" + URL_TOKEN + "=").
					append(secret);
		}

		void appendPathInfo(final StringBuilder bf)
		{
			bf.append(getUrlPath());
			item.appendCopeID(bf);

			if(catchphrase!=null)
				bf.append('/').append(catchphrase);

			if(extension!=null)
				bf.append(extension);
		}

		@Override
		public String toString()
		{
			return getPath();
		}
	}

	@Wrap(order=20, doc="Returns a Locator the content of {0} is available under.")
	public final Locator getLocator(final Item item)
	{
		final String contentType = getContentType(item);

		if(contentType==null)
			return null;

		final MediaType mediaType =
			MediaType.forNameAndAliases(contentType);
		return new Locator(
				item,
				makeUrlCatchphrase(item),
				mediaType!=null ? mediaType.getExtension() : null,
				makeUrlToken(item));
	}

	/**
	 * Returns a URL the content of this media path is available under,
	 * if a {@link MediaServlet} is properly installed.
	 * Returns null, if there is no such content.
	 */
	@Wrap(order=10, doc="Returns a URL the content of {0} is available under.")
	public final String getURL(final Item item)
	{
		final String contentType = getContentType(item);

		if(contentType==null)
			return null;

		final StringBuilder bf = new StringBuilder(getMediaRootUrl());

		bf.append(getUrlPath());
		item.appendCopeID(bf);

		final String catchphrase = makeUrlCatchphrase(item);
		if(catchphrase!=null)
			bf.append('/').append(catchphrase);

		final MediaType type = MediaType.forNameAndAliases(contentType);
		if(type!=null)
			bf.append(type.getExtension());

		final String secret = makeUrlToken(item);
		if(secret!=null)
			bf.append("?" + URL_TOKEN + "=").
				append(secret);

		return bf.toString();
	}

	private final String makeUrlCatchphrase(final Item item)
	{
		if(!(item instanceof MediaUrlCatchphraseProvider))
			return null;

		final String result = ((MediaUrlCatchphraseProvider)item).getMediaUrlCatchphrase(this);
		if(result==null || result.isEmpty())
			return null;

		final int l = result.length();
		for(int i = 0; i<l; i++)
		{
			final char c = result.charAt(i);
			if(! (('0'<=c&&c<='9')||('a'<=c&&c<='z')||('A'<=c&&c<='Z')||(c=='-')) )
				throw new IllegalArgumentException(result);
		}

		return result;
	}

	static final String URL_TOKEN = "t";

	private final String makeUrlToken(final Item item)
	{
		if(!mount().preventUrlGuessing)
			return null;

		final String sss = getNonGuessableUrlSecret();
		if(sss==null)
		{
			final StringBuilder bf = new StringBuilder();
			bf.append(getID()).
				append('-');
			item.appendCopeID(bf);
			return bf.toString();
		}

		final StringBuilder bf = new StringBuilder();
		bf.append(getUrlPath());
		item.appendCopeID(bf);
		bf.append('-').
			append(sss);
		return makeUrlTokenDigest(bf.toString());
	}

	private final String makeUrlToken(final String itemID)
	{
		if(!mount().preventUrlGuessing)
			return null;

		final String sss = getNonGuessableUrlSecret();
		if(sss==null)
			return getID() + '-' + itemID;

		return makeUrlTokenDigest(getUrlPath() + itemID + '-' + sss);
	}

	private final static String makeUrlTokenDigest(final String plainText)
	{
		try
		{
			final MessageDigest messageDigest = MessageDigestUtil.getInstance("SHA-512");
			messageDigest.update(plainText.getBytes(UTF8));
			final byte[] digest = messageDigest.digest();
			final byte[] digestShrink = new byte[10];
			int j = 0;
			for(final byte b : digest)
			{
				digestShrink[j++] ^= b;
				if(j>=digestShrink.length)
					j = 0;
			}
			return Hex.encodeLower(digestShrink);
		}
		catch(final UnsupportedEncodingException e)
		{
			throw new RuntimeException(e);
		}
	}

	public static final boolean isUrlGuessingPreventedSecurely(final ConnectProperties properties)
	{
		return properties.getMediaUrlSecret()!=null;
	}

	private final String getNonGuessableUrlSecret()
	{
		return getType().getModel().getConnectProperties().getMediaUrlSecret();
	}


	private static final VolatileInt noSuchPath = new VolatileInt();
	private final VolatileInt redirectFrom = new VolatileInt();
	private final VolatileInt exception = new VolatileInt();
	private final VolatileInt guessedUrl = new VolatileInt();
	private final VolatileInt notAnItem = new VolatileInt();
	private final VolatileInt noSuchItem = new VolatileInt();
	private final VolatileInt moved = new VolatileInt();
	private final VolatileInt isNull = new VolatileInt();
	private final VolatileInt notComputable = new VolatileInt();
	private final VolatileInt notModified = new VolatileInt();
	private final VolatileInt delivered = new VolatileInt();

	final void incRedirectFrom()
	{
		redirectFrom.inc();
	}

	final void incException()
	{
		exception.inc();
	}

	public static final class NotFound extends Exception
	{
		private final String reason;
		private final VolatileInt counter;

		NotFound(final String reason, final VolatileInt counter)
		{
			this.reason = reason;
			this.counter = counter;

			if(reason==null)
				throw new NullPointerException();
			if(counter==null)
				throw new NullPointerException();
		}

		@Override
		public String getMessage()
		{
			return reason;
		}

		void serve(final HttpServletResponse response) throws IOException
		{
			counter.inc();
			final String body =
				"<html>\n" +
					"<head>\n" +
						"<title>Not Found</title>\n" +
						"<meta http-equiv=\"content-type\" content=\"text/html;charset=us-ascii\">\n" +
						"<meta name=\"generator\" content=\"cope media servlet\">\n" +
					"</head>\n" +
					"<body>\n" +
						"<h1>Not Found</h1>\n" +
						"The requested URL was not found on this server (" + reason + ").\n" +
					"</body>\n" +
				"</html>\n";

			response.setStatus(SC_NOT_FOUND);
			MediaUtil.send("text/html", "us-ascii", body, response);
		}

		private static final long serialVersionUID = 1l;
	}

	static final NotFound notFoundNoSuchPath()
	{
		return new NotFound("no such path", noSuchPath);
	}

	private NotFound notFoundGuessedUrl()
	{
		return new NotFound("guessed url", guessedUrl);
	}

	final NotFound notFoundNotAnItem()
	{
		return new NotFound("not an item", notAnItem);
	}

	private NotFound notFoundNoSuchItem()
	{
		return new NotFound("no such item", noSuchItem);
	}

	protected final NotFound notFoundIsNull()
	{
		return new NotFound("is null", isNull);
	}

	protected final NotFound notFoundNotComputable()
	{
		return new NotFound("not computable", notComputable);
	}

	public static final int getNoSuchPath()
	{
		return noSuchPath.get();
	}

	public final MediaInfo getInfo()
	{
		return new MediaInfo(
				this,
				redirectFrom.get(),
				exception.get(),
				guessedUrl.get(),
				notAnItem.get(),
				noSuchItem.get(),
				moved.get(),
				isNull.get(),
				notComputable.get(),
				notModified.get(),
				delivered.get());
	}


	final void doGet(
			final HttpServletRequest request, final HttpServletResponse response,
			final String pathInfo, final int fromIndex)
		throws IOException, NotFound
	{
		//final long start = System.currentTimeMillis();

		final int slash = pathInfo.indexOf('/', fromIndex);
		final String id;
		if(slash<0)
		{
			final int dot = pathInfo.indexOf('.', fromIndex);
			//System.out.println("trailingDot="+trailingDot);

			if(dot>=0)
				id = pathInfo.substring(fromIndex, dot);
			else
				id = pathInfo.substring(fromIndex);
		}
		else
		{
			id = pathInfo.substring(fromIndex, slash);
		}

		final String token = makeUrlToken(id);
		if(token!=null)
		{
			final String x = request.getParameter(URL_TOKEN);
			if(!token.equals(x))
				throw notFoundGuessedUrl();
		}

		//System.out.println("ID="+id);
		final Model model = getType().getModel();
		try
		{
			model.startTransaction("MediaPath#doGet " + pathInfo);
			final Item item = model.getItem(id);
			//System.out.println("item="+item);
			{
				final Locator locator = getLocator(item);
				if(locator!=null)
				{
					final StringBuilder expectedPathInfo = new StringBuilder();
					expectedPathInfo.append('/');
					locator.appendPathInfo(expectedPathInfo);
					if(!expectedPathInfo.toString().equals(pathInfo))
					{
						final StringBuilder location = new StringBuilder();
						location.
							append(request.getScheme()).
							append("://").
							append(request.getHeader("Host")).
							append(request.getContextPath()).
							append(request.getServletPath()).
							append('/');
						locator.appendPath(location);

						response.setStatus(SC_MOVED_PERMANENTLY);
						response.setHeader("Location", location.toString());
						moved.inc();
						return;
					}
				}
			}

			doGetAndCommitWithCache(request, response, item);

			if(model.hasCurrentTransaction())
				throw new RuntimeException("doGetAndCommit did not commit: " + pathInfo);

			//System.out.println("request for " + toString() + " took " + (System.currentTimeMillis() - start) + " ms, " + id);
		}
		catch(final NoSuchIDException e)
		{
			throw e.notAnID() ? notFoundNotAnItem() : notFoundNoSuchItem();
		}
		finally
		{
			model.rollbackIfNotCommitted();
		}
	}

	protected final void commit()
	{
		getType().getModel().commit();
	}

	@Wrap(order=30, doc="Returns the content type of the media {0}.", hide=ContentTypeGetter.class)
	public abstract String getContentType(Item item);

	private static final class ContentTypeGetter implements BooleanGetter<MediaPath>
	{
		public boolean get(final MediaPath feature)
		{
			return !feature.isContentTypeWrapped();
		}
	}

	// cache

	private static final String REQUEST_IF_MODIFIED_SINCE = "If-Modified-Since";
	private static final String RESPONSE_EXPIRES = "Expires";
	private static final String RESPONSE_LAST_MODIFIED = "Last-Modified";
	private static final String RESPONSE_CACHE_CONTROL = "Cache-Control";
	private static final String RESPONSE_CACHE_CONTROL_PRIVATE = "private";

	private final void doGetAndCommitWithCache(
			final HttpServletRequest request,
			final HttpServletResponse response,
			final Item item)
		throws IOException, NotFound
	{
		// NOTE
		// This code prevents a Denial of Service attack against the caching mechanism.
		// Query strings can be used to effectively disable the cache by using many urls
		// for one media value. Therefore they are forbidden completely.
		if(isUrlGuessingPrevented())
		{
			final String[] tokens = request.getParameterValues(URL_TOKEN);
			if(tokens!=null&&tokens.length>1)
				throw notFoundNotAnItem();
			for(final Enumeration<?> e = request.getParameterNames(); e.hasMoreElements(); )
				if(!URL_TOKEN.equals(e.nextElement()))
					throw notFoundNotAnItem();

			response.setHeader(RESPONSE_CACHE_CONTROL, RESPONSE_CACHE_CONTROL_PRIVATE);
		}
		else
		{
			if(request.getQueryString()!=null)
				throw notFoundNotAnItem();
		}

		final Date lastModifiedRaw = getLastModified(item);
		// if there is no LastModified, then there is no caching
		if(lastModifiedRaw==null)
		{
			doGetAndCommit(request, response, item);
			delivered.inc(); // TODO deliveredUnconditional
			return;
		}

		// NOTE:
		// Last Modification Date must be rounded to full seconds,
		// otherwise comparison for SC_NOT_MODIFIED doesn't work.
		final long lastModified = roundLastModified(lastModifiedRaw);
		//System.out.println("lastModified="+lastModified+"("+getLastModified(item)+")");
		response.setDateHeader(RESPONSE_LAST_MODIFIED, lastModified);

		final long ifModifiedSince = request.getDateHeader(REQUEST_IF_MODIFIED_SINCE);
		//System.out.println("ifModifiedSince="+request.getHeader(REQUEST_IF_MODIFIED_SINCE));
		//System.out.println("ifModifiedSince="+ifModifiedSince);

		final int mediaOffsetExpires = getType().getModel().getConnectProperties().getMediaOffsetExpires();
		if(mediaOffsetExpires>0)
			response.setDateHeader(RESPONSE_EXPIRES, System.currentTimeMillis() + mediaOffsetExpires);

		if(ifModifiedSince>=0 && ifModifiedSince>=lastModified)
		{
			commit();

			//System.out.println("not modified");
			response.setStatus(SC_NOT_MODIFIED);

			//System.out.println(request.getMethod()+' '+request.getProtocol()+" IMS="+format(ifModifiedSince)+"  LM="+format(lastModified)+"  NOT modified");

			notModified.inc();
		}
		else
		{
			doGetAndCommit(request, response, item);
			delivered.inc(); // deliveredConditional
		}
	}

	/**
	 * Copied from com.exedio.cops.Resource.
	 */
	private static long roundLastModified(final Date lastModifiedDate)
	{
		final long lastModified = lastModifiedDate.getTime();
		final long remainder = lastModified%1000;
		return (remainder==0) ? lastModified : (lastModified-remainder+1000);
	}

	/**
	 * The default implementations returns null.
	 * @param item the item which has the LastModified information
	 */
	public Date getLastModified(final Item item)
	{
		return null;
	}

	/**
	 * The implementor MUST {@link #commit() commit} the transaction,
	 * if the method completes normally (without exception).
	 * Otherwise the implementor may or may not commit the transaction.
	 */
	public abstract void doGetAndCommit(HttpServletRequest request, HttpServletResponse response, Item item) throws IOException, NotFound;


	// convenience methods

	/**
	 * Returns a condition matching all items, for which {@link #getLocator(Item)} returns null.
	 */
	public abstract Condition isNull();

	/**
	 * Returns a condition matching all items, for which {@link #getLocator(Item)} returns null.
	 */
	public abstract Condition isNull(final Join join);

	/**
	 * Returns a condition matching all items, for which {@link #getLocator(Item)} does not return null.
	 */
	public abstract Condition isNotNull();

	/**
	 * Returns a condition matching all items, for which {@link #getLocator(Item)} does not return null.
	 */
	public abstract Condition isNotNull(final Join join);

	// ------------------- deprecated stuff -------------------

	@Deprecated
	public final static class Log
	{
		private Log()
		{
			// prevent instantiation
		}

		@SuppressWarnings("static-method")
		public int get()
		{
			throw new NoSuchMethodError();
		}
	}

	/**
	 * @param name is ignored
	 * @deprecated Use {@link #getURL(Item)} and {@link MediaUrlCatchphraseProvider#getMediaUrlCatchphrase(MediaPath)} instead.
	 */
	@Deprecated public final String getNamedURL(final Item item, final String name)
	{
		return getURL(item);
	}
}
